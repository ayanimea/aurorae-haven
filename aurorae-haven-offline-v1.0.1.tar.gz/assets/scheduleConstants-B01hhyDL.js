const E={ROUTINE:"routine",TASK:"task",MEETING:"meeting",HABIT:"habit",BREAK:"break",EVENT:"event"},T=Object.values(E),_=30,s=0,A=0,I=180,t=180;export{A as D,E,_ as F,I as M,T as V,t as a,s as b};
